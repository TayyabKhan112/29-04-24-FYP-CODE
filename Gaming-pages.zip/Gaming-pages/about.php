<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>About Us</title>

    <!-- Vendor CSS Files -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-5.0.2.min.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome-6.5.1.min.css" />

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/responsive.css" />

  </head>
  <body> 
    <!-- Navbar start -->
    <div class="bg-dark-nav sticky-top">
      <div class="container">
        <header class="bg-dark-nav">
          <div class="logo">
            <a href="index.php">
              <img src="assets/images/logo.png" alt="">
            </a>
          </div>
          <input type="checkbox" id="nav_check" hidden />
          <nav>
            <ul>
              <li>
                <a href="tournaments.php">Tournament</a>
              </li>
              <li>
                <a href="leaderboard.php">Leaderboard</a>
              </li>
              <li>
                <a href="chat.php">Messages</a>
              </li>
              <li>
                <a href="about.php">About</a>
              </li>
              <li>
                <a href="register.php">Sign Up</a>
              </li>
              <li>
                <a href="login.php">Sign In</a>
              </li>
            </ul>
          </nav>
          <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
          </label>
        </header>
      </div>
    </div>
    <!-- Navbar End -->

    <!-- About Us Section -->
    <div class="about-us mt-5">
      <div class="container">
        <div class="about-us">
          <div class="section-title">
              <h2>About Us</h2>
          </div>
          <p>
            Welcome to Gaming Bunny, a vibrant community dedicated to empowering and supporting female gamers. We understand that gaming should be an enjoyable and inclusive experience for everyone, yet far too often, female gamers encounter harassment, discrimination, and bullying in mainstream gaming environments. That's why we've created this space—a haven where women can connect, share their stories, and celebrate their love for gaming without fear or judgment.
          </p>
        </div>
      </div>
    </div>

    <!-- Main Content Section -->

    <!-- Our Misson -->
    <section class="our-mission">
      <div class="container">
        <div class="row">

          <div class="col-lg-6">
            <div class="our-mission-left">
              <img src="https://as1.ftcdn.net/v2/jpg/04/01/92/00/1000_F_401920064_gh0hFdIWc3W0S9aba42845ca2uRNnPrK.jpg" alt="">
            </div>
          </div>

          <div class="col-lg-6">
            <div class="our-mission-right">
              <div class="our-mission-right-content">
               <div class="section-title">
                <h2 class="text-left" >Our Mission</h2>
              </div>
                <p>At Gaming Bunny, our mission is simple: to foster a welcoming and supportive community for female gamers who have faced adversity in the gaming world. We believe that every woman has the right to game without facing discrimination or harassment, and we're committed to creating a space where that vision becomes a reality. Through solidarity, advocacy, and mutual support, we strive to empower female gamers and promote inclusivity in the gaming industry.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

     <!-- What We Offer -->
     <section class="what-we-offer">
        <div class="container">
          <div class="section-title">
              <h2 class="text-center">What We Offer</h2>
          </div>
          <div class="row">

            <div class="col-lg-3">
              <div class="offer-content">
                  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRb0xIWCi_RKrxZtdHkbgL9_GSTHVq8nwdmiCS233Nmn3oLBZuPFgjrtEWGXG4SmTItwks&usqp=CAU" alt="">
                  <p>A Safe Space: Our community provides a safe and supportive environment where female gamers can share their experiences, seek advice, and connect with others who understand the challenges they face.</p>
              </div>
            </div>

            <div class="col-lg-3">
              <div class="offer-content">
                 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRluuxP1uWSKqYfPGmiGwGlqxygj_STQVLJY0Np-qwTjdDNQmt004xCk9dDMHXK7rEIpuI&usqp=CAU" alt="">
                 <p>Resources and Support: Whether you're dealing with harassment in online games or seeking guidance on navigating male-dominated gaming spaces, we offer resources, support, and solidarity to help you through.</p>
              </div>
            </div>

            <div class="col-lg-3">
              <div class="offer-content">
                 <img src="https://i.pinimg.com/736x/29/5c/a1/295ca14b405281e168de07e55326322f.jpg" alt="">
                 <p>Empowerment: We believe in the power of female gamers to effect positive change in the gaming industry. By coming together, sharing our stories, and advocating for inclusivity, we can make a difference and create a more welcoming environment for all gamers.</p>
              </div>
            </div>

            <div class="col-lg-3">
              <div class="offer-content">
                 <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSj-foJ7reeYLNaH0ytp9_pFcS5Qc6fkemH7v1Hd-PlajgSuwsXGBIX7S0heeWLsrJnOdo&usqp=CAU" alt="">
                 <p>Community Engagement: From online forums to community events, we provide opportunities for members to engage with one another, share their passions, and build lasting friendships with fellow female gamers.</p>
              </div>
            </div> 

          </div>
        </div>
     </section>

     <!-- Join Us -->
    <section class="join-us">
      <div class="container">

        <div class="section-title">
          <h2>Join Us</h2>
        </div>

        <div class="row">
          <div class="col-lg-12">
            <div class="join-us-content">
              <p>If you're tired of feeling isolated or marginalized in gaming spaces, we invite you to join us at Gaming Bunny. Together, we can challenge stereotypes, combat harassment, and build a more inclusive gaming community where every woman feels welcome and respected. Whether you're a casual gamer, a competitive player, or somewhere in between, you have a place here. Join us today and be part of the movement to make gaming better for everyone.</p>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- FAQ Section -->
    <div class="jumbotron jumbotron-fluid text-center mt-5">
      <div class="container">
        <h1 class="display-4">Frequently Asked Questions</h1>
      </div>
    </div>

    <!-- FAQ Content Section -->
    <div class="container">
      <div class="accordion-wrapper mt-5">
        <div class="accordion">
          <input type="radio" name="radio-a" id="check1" checked />
          <label class="accordion-label" for="check1">What is this website about?</label>
          <div class="accordion-content">
            <p>
              This website is dedicated to providing a safe and supportive community for female gamers who may have experienced bullying or harassment in mainstream gaming environments. We aim to create a space where women can connect, share experiences, and enjoy gaming without fear of discrimination or mistreatment.
            </p>
          </div>
        </div>
        <div class="accordion">
          <input type="radio" name="radio-a" id="check2" />
          <label class="accordion-label" for="check2"> Why is there a need for a community specifically for female gamers?</label>
          <div class="accordion-content">
            <p>
              Unfortunately, many female gamers encounter harassment, sexism, and bullying in mainstream gaming spaces. This community aims to address those issues by providing a supportive environment where women can feel empowered to share their experiences and find solidarity with others facing similar challenges.
            </p>
          </div>
        </div>

        <div class="accordion">
          <input type="radio" name="radio-a" id="check3" />
          <label class="accordion-label" for="check3">How can I participate in this community?</label>
          <div class="accordion-content">
            <p>
              - You can participate in this community by joining our online forums, engaging in discussions, sharing your gaming experiences, and connecting with other female gamers. We also encourage you to contribute to the community by sharing resources, offering support to others, and helping to foster a positive and inclusive atmosphere.
            </p>
          </div>
        </div>

        <div class="accordion">
          <input type="radio" name="radio-a" id="check4" />
          <label class="accordion-label" for="check4">Is this community only for women who have experienced harassment or bullying?</label>
          <div class="accordion-content">
            <p>
              While this community is specifically designed for female gamers who may have experienced harassment or bullying, it is open to all women who are passionate about gaming and want to connect with others who share their interests. We welcome individuals of all backgrounds and experiences to join us in creating a welcoming and supportive community.
            </p>
          </div>
        </div>

        <div class="accordion">
          <input type="radio" name="radio-a" id="check5" />
          <label class="accordion-label" for="check5">How does this community support members who have experienced harassment or bullying?</label>
          <div class="accordion-content">
            <p>
              Our community provides a safe space where members can share their experiences and receive support from others who understand what they're going through. We offer resources and guidance on dealing with harassment and bullying, as well as strategies for promoting inclusivity and combating discrimination in gaming spaces.
            </p>
          </div>
        </div>

        <div class="accordion">
          <input type="radio" name="radio-a" id="check6" />
          <label class="accordion-label" for="check6">What steps are taken to ensure the safety and privacy of community members?</label>
          <div class="accordion-content">
            <p>
              We take the safety and privacy of our community members very seriously. We have strict moderation policies in place to ensure that our forums remain free from harassment, hate speech, and other forms of harmful behaviour. We also provide tools for members to report any inappropriate conduct, and we take prompt action to address violations of our community guidelines.
            </p>
          </div>
        </div>

        <div class="accordion">
          <input type="radio" name="radio-a" id="check7" />
          <label class="accordion-label" for="check7">How can I get involved in advocating for greater inclusivity and diversity in the gaming industry?</label>
          <div class="accordion-content">
            <p>
              There are many ways to advocate for greater inclusivity and diversity in the gaming industry, both within our community and beyond. You can support diverse creators and content, speak out against harassment and discrimination, and actively work to create more inclusive gaming spaces. We also provide resources and opportunities for members to get involved in advocacy efforts and make their voices heard.
            </p>
          </div>
        </div>  

      </div>
    </div>

    <!-- Hero Section -->
    <div class="jumbotron jumbotron-fluid text-center mt-5">
      <div class="container">
        <div class="section-title">
          <h2>Admin Support</h2>
        </div>
      </div>
    </div>

    <!-- Main Content Section -->
    <div class="container">
      <p class="mt-5 text-center">
        Live support hours: 12PM EST - 4AM EST every day.
      </p>
      <p class="mt-5 text-center">
        If you don’t have our Prestige membership you can still receive support
        on the @‌CallofDutyAgent
      </p>
      <p class="mt-1 text-center">
        Twitter or by emailing us at sthorsteinson@esportsagent.gg. Most
        messages should receive a response
      </p>
      <p class="mt-1 text-center">
        in minutes, but may take up to but no longer than 3 hours.
      </p>
    </div>

    <!-- Footer -->
    <footer class="footer mt-5">
      <div class="container">
        <span>© 2024 </span>
      </div>
    </footer>

    <!-- Jquery 3.7.1 -->
    <script src="assets/vendor/jquery-3.7.1.min.js"></script>
    <!-- Popper js 2.9.2 -->
    <script src="assets/vendor/popper-2.9.2.min.js"></script>
    <!-- Bootstrap js 5.0.2 -->
    <script src="assets/vendor/bootstrap-5.0.2.min.js"></script>
    <!-- Custom js -->
    <script src="assets/js/script.js"></script>
  </body>
</html>

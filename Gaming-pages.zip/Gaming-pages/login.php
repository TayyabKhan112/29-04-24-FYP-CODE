<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="assets/css/login.css" />
</head>
<body>
    <div class="login-box">
    <h2>Sign In</h2>
    <form id="login-form" method="POST">
        <div class="user-box">
        <input type="email" name="email" id="email" required="">
        <label>Email</label>
        </div>
        <div id="email-error" class="error-message"></div>

        <div class="user-box">
            <input type="password" name="password" id="password" required="">
            <label>Password</label>
        </div>
        <div id="password-error" class="error-message"></div>

        <input type="hidden" name="login_submit" id="login_submit" value="login">

        <a href="#" id="submit-btn">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            Submit
        </a>
    </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
      $(document).ready(function () {
        $("#submit-btn").click(function () {
          $(".error-message").empty();

          var email = $("#email").val();
          var password = $("#password").val();
          var login_submit = $("#login_submit").val();

          var isValid = true;

          if (email.trim() === "") {
            $("#email-error").text("Please enter your email.");
            isValid = false;
          }

          if (password.trim() === "") {
            $("#password-error").text("Please enter your password.");
            isValid = false;
          }

          if (isValid) {
            var formData = {
              email: email,
              password: password,
              login_submit: login_submit,
            };

            $.ajax({
              type: "POST",
              url: "submit.php",
              data: formData,
              success: function (response) {
                if(response === "success"){
                    window.location.href = "index.php";
                }else{
                    alert(response);
                    setTimeout(() => {
                        window.location.reload();
                    }, 3000);
                }
              },
              error: function (xhr, status, error) {
                alert(error.message);
              },
            });
          }
        });
      });
    </script>
</body>
</html>
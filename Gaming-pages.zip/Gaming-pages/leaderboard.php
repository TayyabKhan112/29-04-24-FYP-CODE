<?php 
  require "config.php";
  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: {$host}/login.php");
  }

  //here I am getting leaderboard data from databse
  $sql = "SELECT leaderboard.point, users.full_name 
          FROM leaderboard 
          INNER JOIN users ON leaderboard.user_id = users.id 
          ORDER BY leaderboard.point DESC";
  $result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Leaderboard</title>

    <!-- Vendor CSS Files -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-5.0.2.min.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome-6.5.1.min.css" />

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/responsive.css" />
    <link rel="stylesheet" href="assets/css/login.css" />

  </head>
  <body>
    <!-- Navbar start -->
    <div class="bg-dark-nav sticky-top">
      <div class="container">
        <header class="bg-dark-nav">
          <div class="logo">
            <a href="index.php">
              <img src="assets/images/logo.png" alt="">
            </a>
          </div>
          <input type="checkbox" id="nav_check" hidden />
          <nav>
            <ul>
              <li>
                <a href="tournaments.php">Tournament</a>
              </li>
              <li>
                <a href="leaderboard.php">Leaderboard</a>
              </li>
              <li>
                <a href="chat.php">Messages</a>
              </li>
              <li>
                <a href="about.php">About</a>
              </li>
              <li>
                <a href="register.php">Sign Up</a>
              </li>
              <?php if(!isset($_SESSION['user'])){ ?>
              <li>
                <a href="login.php">Sign In</a>
              </li>
              <?php }else{ ?>
              <li>
                <a href="logout.php">Sign Out</a>
              </li>
              <?php } ?>
            </ul>
          </nav>
          <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
          </label>
        </header>
      </div>
    </div>
    <!-- Navbar End -->

    <!-- Hero Section -->
    <div class="jumbotron jumbotron-fluid text-center mt-5">
      <div class="container">
        <div class="section-title">
          <h2>Leaderboard</h2>
        </div>
      </div>
      <div class="container d-flex justify-content-end mb-3">
        <button type="button" class="btn btn-primary" id="addPointBtn" style="background: #696cff !important; color: #fff !important;">
          ADD POINT
        </button>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content" style="background: #232333 !important;">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add Game Point</h5>
          </div>
          <div class="modal-body">
          <form>
            <div class="form-group">
              <label for="message-text" class="col-form-label">Point</label>
              <textarea class="form-control" id="point" name="point" oninput="this.value = this.value.replace(/[^0-9]/g, '')"></textarea>
            </div>
            <div id="point-error" class="error-message"></div>

            <input type="hidden" name="point_submit" id="point_submit" value="yes">
            <br><br>

            <button type="button" class="btn btn-primary" id="submit-btn" style="background: #696cff !important; color: #fff !important;">Submit</button>
          </form>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Main Content Section -->
    <div class="container">
      <table>
        <thead>
          <tr>
            <th class="rank">RANK</th>
            <th class="user">USER</th>
            <th class="elo">Point</th>
          </tr>
        </thead>
        <tbody>
          <?php 
            $rank = 1;
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>";
              echo "<td>" . $rank . "</td>";
              echo "<td>" . $row['full_name'] . "</td>";
              echo "<td>" . $row['point'] . "</td>";
              echo "</tr>";
              $rank++;
            }
          ?>
        </tbody>
      </table>
    </div>

    

    <!-- Popper js 2.9.2 -->
    <script src="assets/vendor/popper-2.9.2.min.js"></script>
    <!-- Bootstrap js 5.0.2 -->
    <script src="assets/vendor/bootstrap-5.0.2.min.js"></script>
    <!-- Custom js -->
    <script src="assets/js/script.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
      $(document).ready(function(){
        $('#addPointBtn').click(function(){
          $('#exampleModal').modal('show');
        });
      });

      $(document).ready(function () {
        $("#submit-btn").click(function () {
          $(".error-message").empty();

          var point = $("#point").val();
          var point_submit = $("#point_submit").val();

          // Perform validation
          var isValid = true;
          if (point.trim() === "") {
            $("#point-error").text("Please enter your point value.");
            isValid = false;
          }

          if (isValid) {
            var formData = {
              point: point,
              point_submit: point_submit,
            };

            $.ajax({
              type: "POST",
              url: "submit.php",
              data: formData,
              success: function (response) {
                if(response === "success"){
                    window.location.reload();
                }else{
                    alert("Something went wrong");
                    setTimeout(() => {
                        window.location.reload();
                    }, 5000);
                }
              },
              error: function (xhr, status, error) {
                alert(error.message);
              },
            });
          }
        });
      });
    </script>
  </body>

</html>

<?php 
  require "config.php";
  $swearWords = array("Shit", "Bullshit", "Bloody", "Fuck", "Bitch", "Cunt");
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Home</title>

    <!-- Vendor CSS Files -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-5.0.2.min.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome-6.5.1.min.css" />

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/responsive.css" />

  </head>
  <body>
    <!-- Navbar start -->
    <div class="bg-dark-nav sticky-top">
      <div class="container">
        <header class="bg-dark-nav">
          <div class="logo">
            <a href="index.php">
              <img src="assets/images/logo.png" alt="">
            </a>
          </div>
          <input type="checkbox" id="nav_check" hidden />
          <nav>
            <ul>
              <li>
                <a href="tournaments.php">Tournament</a>
              </li>
              <li>
                <a href="leaderboard.php">Leaderboard</a>
              </li>
              <li>
                <a href="chat.php">Messages</a>
              </li>
      
              <li>
                <a href="about.php">About</a>
              </li>
         
              <li>
                <a href="register.php">Sign Up</a>
              </li>
              <?php if(!isset($_SESSION['user'])){ ?>
              <li>
                <a href="login.php">Sign In</a>
              </li>
              <?php }else{ ?>
              <li>
                <a href="logout.php">Sign Out</a>
              </li>
              <?php } ?>
            </ul>
          </nav>
          <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
          </label>
        </header>
      </div>
    </div>
    <!-- Navbar End -->

    <!-- Hero Section -->
    <div class="jumbotron jumbotron-fluid text-center mt-5">
      <div class="container">
        <div class="section-title">
          <h2>Your competitive journey starts here</h2>
        </div>
        <p class="lead">
          Find your favorite games! 
        </p>
      </div>
    </div>

    <!-- Main Content Section -->
    <div class="container">
      <div class="mt-5">
        <span class="d-block section-title blog-content">
          <h2>Upcoming Tournaments</h2>
          <?php if(isset($_SESSION['user'])){ ?>
          <a href="#" data-bs-toggle="modal" data-bs-target="#blgoModal">Add Blog</a>
          <?php } ?>
          <!-- Modal -->
            <div class="modal fade" id="blgoModal" tabindex="-1" aria-labelledby="blgoModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h1 class="modal-title fs-5 text-dark" id="blgoModalLabel">Blog</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <form id="blog-form" enctype="multipart/form-data">

                      <div class="mb-3">
                        <label for="title" class="form-label">Title</label>
                        <input type="text" class="form-control" id="title" name="title">
                      </div>
                      <div id="title-error" class="error-message"></div>

                      <div class="mb-3">
                        <label for="description" class="form-label">Description</label>
                        <input type="text" class="form-control" id="description" name="description">
                      </div>
                      <div id="description-error" class="error-message"></div>

                      <div class="mb-3">
                        <label for="image" class="form-label">Upload Image</label>
                        <input type="file" class="form-control" id="image" name="image">
                      </div>
                      <div id="image-error" class="error-message"></div>
                      <input type="hidden" name="blog_submit" id="blog_submit" value="yes">

                      <button type="button" class="btn btn-primary" id="blog-submit-btn">Submit</button>

                    </form>
                  </div>
                </div>
              </div>
            </div>
        </span>
        <div class="row">
        <?php
            // Fetch blog data from the database
            $sql = "SELECT * FROM blog";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                // Loop through each row of blog data
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-lg-4 mt-5">
                        <div class="card tournament-card">
                            <img src="<?php echo $row['image']; ?>" class="card-img-top" alt="Tournament Image">
                            <div class="card-body">
                                <h4><?php echo $row['title']; ?></h4>
                                <p><?php echo $row['description']; ?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                echo "No blogs found.";
            }
            ?>
          <!-- <div class="col-lg-4 mt-5">
            <a href="tournament-details.php">
              <div class="card tournament-card">
                <img
                  src="https://bunnygaming.com/wp-content/uploads/2024/04/cold-seel-1068x601.jpg"
                  class="card-img-top"
                  alt="Tournament Image"
                />
                <div class="card-body">
                  <h4>
                  The Global Release Of ‘The Legend of Heroes: Trails of Cold Steel – Northern War’ Is Scheduled for May 29th</h4>
                 <p>USERJOY announces the upcoming release of The Legend of Heroes: Trails of Cold Steel - Northern War Global Version,...</p>
                </div>
              </div>
            </a>
          </div> -->
        </div>
      </div>

      <!-- Report Section -->

        <div class="row">
          <!-- Report -->
          <div class="col-lg-12 mt-5">
            <div class="report-btn text-center">
              <a href="#" data-bs-toggle="modal" data-bs-target="#reportModal">
              Report
            </a>
            <!-- Modal -->
            <div class="modal fade" id="reportModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <h1 class="modal-title fs-5 text-dark" id="exampleModalLabel">Report</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                  <form>
                      <div class="mb-3">
                          <label for="username" class="form-label">Username</label>
                          <input type="text" class="form-control" id="username" name="username">
                      </div>
                      <div id="username-error" class="error-message"></div>
                      <div class="mb-3">
                          <label for="message" class="form-label">Message</label>
                          <textarea class="form-control" id="message" name="message"></textarea>
                      </div>
                      <div id="message-error" class="error-message"></div>
                      <input type="hidden" name="report_submit" id="report_submit" value="yes">
                      <button type="button" class="btn btn-primary" id="report-submit-btn">Submit</button>
                  </form>
                  </div>
                </div>
              </div>
            </div>

            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Footer -->
    <footer class="footer mt-5">
      <div class="container">
        <span>© 2024 eSports Agent</span>
      </div>
    </footer>

    <!-- Jquery 3.7.1 -->
    <script src="assets/vendor/jquery-3.7.1.min.js"></script>
    <!-- Popper js 2.9.2 -->
    <script src="assets/vendor/popper-2.9.2.min.js"></script>
    <!-- Bootstrap js 5.0.2 -->
    <script src="assets/vendor/bootstrap-5.0.2.min.js"></script>
    <!-- Custom js -->
    <script src="assets/js/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>

    $(document).ready(function () {
        $("#report-submit-btn").click(function () {
            $(".error-message").empty();

            var formData = $("form").serialize(); // Serialize the form data
            
            // Perform validation
            var isValid = true;
            var username = $("#username").val(); // Retrieve username separately for additional validation
            var message = $("#message").val(); // Retrieve message separately for additional validation

            if (username.trim() === "") {
                $("#username-error").text("Please enter your username.");
                isValid = false;
            }

            if (message.trim() === "") {
                $("#message-error").text("Please enter your message.");
                isValid = false;
            }

            if (containsSwearWord(message)) {
                alert("Please don't use swear words.");
                return;
            }

            if (isValid) {
                $.ajax({
                    type: "POST",
                    url: "submit.php",
                    data: formData, // Use serialized form data
                    success: function (response) {
                        if(response === "success"){
                            $('#reportModal').modal('hide');
                            alert("Report submitted successfully.");
                            setTimeout(() => {
                                window.location.reload();
                            }, 1000);
                        } else {
                            alert("Something went wrong");
                            setTimeout(() => {
                                window.location.reload();
                            }, 5000);
                        }
                    },
                    error: function (xhr, status, error) {
                        alert(error.message);
                    },
                });
            }
        });

        $("#blog-submit-btn").click(function () {
          $(".error-message").empty();

          var formData = new FormData($("#blog-form")[0]);
          
          // Perform validation
          var isValid = true;
          var title = $("#title").val();
          var description = $("#description").val();
          var image = $("#image").val();

          if (title.trim() === "") {
              $("#title-error").text("Please enter your title.");
              isValid = false;
          }

          if (description.trim() === "") {
              $("#description-error").text("Please enter your description.");
              isValid = false;
          }

          if (image.trim() === "") {
              $("#image-error").text("Please give blog image.");
              isValid = false;
          }

          if (isValid) {
              $.ajax({
                  type: "POST",
                  url: "submit.php",
                  data: formData,
                  contentType: false,
                  processData: false,
                  success: function (response) {
                      if(response == "success"){
                          $('#blogModal').modal('hide');
                          alert("Blog created successfully.");
                          setTimeout(() => {
                              window.location.reload();
                          }, 1000);
                      } else {
                          alert("Something went wrong");
                          setTimeout(() => {
                              window.location.reload();
                          }, 5000);
                      }
                  },
                  error: function (xhr, status, error) {
                      alert(error.message);
                  },
              });
          }
      });
    });


      function containsSwearWord(message) {
        var swearWords = <?php echo json_encode($swearWords); ?>;
        var lowerCaseMessage = message.toLowerCase();
        for (var i = 0; i < swearWords.length; i++) {
            if (lowerCaseMessage.includes(swearWords[i].toLowerCase())) {
                return true;
            }
        }
        return false;
      }
    </script>
  </body>
</html>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require "config.php";
session_start();

//this function for register
if(isset($_POST['register_submit']) && !empty($_POST['register_submit'])){
    $full_name = $_POST['full_name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $full_name = mysqli_real_escape_string($conn, $full_name);
    $username = mysqli_real_escape_string($conn, $username);
    $email = mysqli_real_escape_string($conn, $email);
    $password = md5($password);

    $sql = "INSERT INTO users (full_name, username, email, password) VALUES ('$full_name', '$username', '$email', '$password')";
    if (mysqli_query($conn, $sql)) {
        $last_inserted_id = mysqli_insert_id($conn);
        $_SESSION['user']['id'] = $last_inserted_id;
        $_SESSION['user']['username'] = $username;
        $_SESSION['user']['full_name'] = $full_name;
        $_SESSION['user']['email'] = $email;
        echo "success";
    } else {
        echo "error";
    }
    return;
}

//this function for login
if(isset($_POST['login_submit']) && !empty($_POST['login_submit'])){
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $email = mysqli_real_escape_string($conn, $email);
    $password = md5($password);

    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        if($user['password'] === $password) {
            $_SESSION['user']['id'] = $user['id'];
            $_SESSION['user']['username'] = $user['username'];
            $_SESSION['user']['full_name'] = $user['full_name'];
            $_SESSION['user']['email'] = $user['email'];
            echo "success";
        } else {
            echo "error: Incorrect email or password.";
        }
    } else {
        echo "error: Incorrect email or password.";
    }
    return;
}

//this function for point save
if(isset($_POST['point_submit']) && !empty($_POST['point_submit'])){
    $user_id = $_SESSION['user']['id'];
    $point = $_POST['point'];
    $point = mysqli_real_escape_string($conn, $point);

    $query = "SELECT * from leaderboard where user_id = $user_id";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0) {
        $sql = "UPDATE leaderboard SET point = '$point' WHERE user_id = $user_id";
        if (mysqli_query($conn, $sql)) {
            echo "success";
        }else{
            echo "error";
        }
    } else {
        $sql = "INSERT INTO leaderboard (user_id, point) VALUES ('$user_id', '$point')";
        if (mysqli_query($conn, $sql)) {
            echo "success";
        } else {
            echo "error";
        }
    }
    return;
}

//this function for get chat from database
if(isset($_GET['get_chat']) && !empty($_GET['get_chat'])){
    $sender_id = $_GET['sender_id'];
    $receiver_id = $_GET['receiver_id'];

    $sql = "SELECT * FROM chats 
        WHERE (sender_id = '$sender_id' AND receiver_id = '$receiver_id') 
           OR (sender_id = '$receiver_id' AND receiver_id = '$sender_id') 
        ORDER BY created_at ASC";
    $result = mysqli_query($conn, $sql);
    $messages = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $messages[] = $row;
    }

    header('Content-Type: application/json');
    echo json_encode($messages);
    return;
}

//this function for save chat
if(isset($_POST['save_chat']) && !empty($_POST['save_chat'])){
    $sender_id = $_POST['sender_id'];
    $receiver_id = $_POST['receiver_id'];
    $message = $_POST['message'];

    $sql = "INSERT INTO chats (sender_id, receiver_id, message) VALUES ('$sender_id', '$receiver_id', '$message')";
    $result = mysqli_query($conn, $sql);
    
    if ($result) {
        $last_inserted_id = mysqli_insert_id($conn);
    
        $sql_select = "SELECT * FROM chats WHERE id = '$last_inserted_id'";
        $result_select = mysqli_query($conn, $sql_select);
        $inserted_data = mysqli_fetch_assoc($result_select);
    }

    header('Content-Type: application/json');
    echo json_encode($inserted_data);
    return;
}

//this function for report save
if(isset($_POST['report_submit']) && !empty($_POST['report_submit'])){
    $username = $_POST['username'];
    $message = $_POST['message'];
    $username = mysqli_real_escape_string($conn, $username);
    $message = mysqli_real_escape_string($conn, $message);

    $sql = "INSERT INTO report (username, message) VALUES ('$username', '$message')";
    if (mysqli_query($conn, $sql)) {
        echo "success";
    } else {
        echo "error";
    }
    return;
}

//this function for blog save
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['blog_submit']) && $_POST['blog_submit'] == "yes") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($image_name);
    move_uploaded_file($image_tmp, $target_file);

    // Prepare the SQL statement
    $sql = "INSERT INTO blog (title, description, image) VALUES (?, ?, ?)";

    // Prepare and bind parameters
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $title, $description, $target_file);

    // Execute the statement
    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
    return;
}

?>



CREATE TABLE `chats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `message` text NOT NULL,
  `seen_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
)
;
INSERT INTO `chats` VALUES (1,4,6,'test',NULL,'2024-04-19 16:42:04','2024-04-19 16:42:04'),(2,6,4,'reply',NULL,'2024-04-19 17:33:30','2024-04-19 17:33:30'),(3,6,4,'test message',NULL,'2024-04-19 17:54:03','2024-04-19 17:54:03'),(4,6,4,'test message',NULL,'2024-04-19 17:54:36','2024-04-19 17:54:36'),(5,6,4,'test message again',NULL,'2024-04-19 17:56:09','2024-04-19 17:56:09'),(6,6,4,'test message again again',NULL,'2024-04-19 17:58:21','2024-04-19 17:58:21'),(7,6,4,'test message again again',NULL,'2024-04-19 18:02:40','2024-04-19 18:02:40'),(8,6,4,'hello',NULL,'2024-04-19 18:03:14','2024-04-19 18:03:14'),(9,6,4,'hello',NULL,'2024-04-19 18:05:54','2024-04-19 18:05:54'),(10,10,6,'hello ridoy',NULL,'2024-04-19 18:16:23','2024-04-19 18:16:23'),(11,10,4,'hello Ayazul',NULL,'2024-04-19 18:16:37','2024-04-19 18:16:37');

CREATE TABLE `leaderboard` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `point` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

INSERT INTO `leaderboard` VALUES (1,4,12,'2024-04-18 06:37:57','2024-04-18 06:37:57'),(2,6,15,'2024-04-18 06:42:32','2024-04-18 06:42:32'),(3,10,100,'2024-04-19 18:18:36','2024-04-19 18:18:36');

CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
);

INSERT INTO `users` VALUES (4,'Ayazul','ridoy','ayazulridoy@gmail.com','14e1b600b1fd579f47433b88e8d85291','2024-04-17 19:02:15','2024-04-17 19:02:15'),(6,'Ridoy','ayazul','ridoyayazul@gmail.com','14e1b600b1fd579f47433b88e8d85291','2024-04-17 19:39:53','2024-04-17 19:39:53'),(10,'Kawser Ahmed','kawser','kawser@gmail.com','14e1b600b1fd579f47433b88e8d85291','2024-04-19 18:15:43','2024-04-19 18:15:43');

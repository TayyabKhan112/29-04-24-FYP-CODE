<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/login.css" />
</head>
<body>
    <div class="login-box">
    <h2>Sign Up</h2>
    <form id="register-form" method="POST">
        <div class="user-box">
            <input type="text" name="full_name" id="full_name" required="">
            <label>Fullname</label>
        </div>
        <div id="full_name-error" class="error-message"></div>

        <div class="user-box">
            <input type="text" name="username" id="username" required="">
            <label>Username</label>
        </div>
        <div id="username-error" class="error-message"></div>

        <div class="user-box">
            <input type="text" name="email" id="email" required="">
            <label>Email</label>
        </div>
        <div id="email-error" class="error-message"></div>

        <div class="user-box">
            <input type="password" name="password" id="password" required="">
            <label>Password</label>
        </div>
        <div id="password-error" class="error-message"></div>

        <input type="hidden" name="register_submit" id="register_submit" value="register">

        <a href="#" id="submit-btn">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            Submit
        </a>
    </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
      $(document).ready(function () {
        $("#submit-btn").click(function () {
          $(".error-message").empty();

          var full_name = $("#full_name").val();
          var username = $("#username").val();
          var email = $("#email").val();
          var password = $("#password").val();
          var register_submit = $("#register_submit").val();

          // Perform validation
          var isValid = true;
          if (full_name.trim() === "") {
            $("#full_name-error").text("Please enter your full name.");
            isValid = false;
          }

          if (username.trim() === "") {
            $("#username-error").text("Please enter your username.");
            isValid = false;
          }

          if (email.trim() === "") {
            $("#email-error").text("Please enter your email.");
            isValid = false;
          }

          if (password.trim() === "") {
            $("#password-error").text("Please enter your password.");
            isValid = false;
          }

          if (isValid) {
            var formData = {
              full_name: full_name,
              username: username,
              email: email,
              password: password,
              register_submit: register_submit,
            };

            $.ajax({
              type: "POST",
              url: "submit.php",
              data: formData,
              success: function (response) {
                if(response === "success"){
                    window.location.href = "index.php";
                }else{
                    alert("Something went wrong");
                    setTimeout(() => {
                        window.location.reload();
                    }, 5000);
                }
              },
              error: function (xhr, status, error) {
                alert(error.message);
              },
            });
          }
        });
      });
    </script>
</body>
</html>
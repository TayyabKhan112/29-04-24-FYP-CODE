<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Tournament Details</title>

    <!-- Vendor CSS Files -->
    <link rel="stylesheet" href="assets/vendor/bootstrap-5.0.2.min.css" />
    <link rel="stylesheet" href="assets/vendor/font-awesome-6.5.1.min.css" />

    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Ruluko&family=Sora:wght@100..800&display=swap" rel="stylesheet">

    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/css/responsive.css" />
  </head>
  <body>
    <!-- Navbar start -->
    <div class="bg-dark-nav sticky-top">
      <div class="container">
        <header class="bg-dark-nav">
          <div class="logo">
            <a href="index.php">
              <img src="assets/images/logo.png" alt="">
            </a>
          </div>
          <input type="checkbox" id="nav_check" hidden />
          <nav>
            <ul>
              <li>
                <a href="tournaments.php">Tournament</a>
              </li>
              <li>
                <a href="leaderboard.php">Leaderboard</a>
              </li>
              <li>
                <a href="chat.php">Messages</a>
              </li>
              <li>
                <a href="about.php">About</a>
              </li>
              <li>
                <a href="register.php">Sign Up</a>
              </li>
              <?php if(!isset($_SESSION['user'])){ ?>
              <li>
                <a href="login.php">Sign In</a>
              </li>
              <?php }else{ ?>
              <li>
                <a href="logout.php">Sign Out</a>
              </li>
              <?php } ?>
            </ul>
          </nav>
          <label for="nav_check" class="hamburger">
            <div></div>
            <div></div>
            <div></div>
          </label>
        </header>
      </div>
    </div>
    <!-- Navbar End -->

    <!-- Hero Section -->
    <div class="jumbotron jumbotron-fluid text-center mt-5">
      <div class="container">
        <div class="section-title">
          <h2>Tournament Details</h2>
        </div>
      </div>
    </div>

    <!-- Main Content Section -->
    <div class="container"></div>

    <!-- Jquery 3.7.1 -->
    <script src="../assets/vendor/jquery-3.7.1.min.js"></script>
    <!-- Popper js 2.9.2 -->
    <script src="../assets/vendor/popper-2.9.2.min.js"></script>
    <!-- Bootstrap js 5.0.2 -->
    <script src="../assets/vendor/bootstrap-5.0.2.min.js"></script>
    <!-- Custom js -->
    <script src="../assets/js/script.js"></script>
  </body>
</html>

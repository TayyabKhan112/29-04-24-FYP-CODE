<?php 
  error_reporting(E_ALL);
  ini_set('display_errors', 1);

  require "config.php";
  $swearWords = array("Shit", "Bullshit", "Bloody", "Fuck", "Bitch", "Cunt");

  session_start();
  if(!isset($_SESSION['user'])){
    header("Location: {$host}/login.php");
  }

  $user_id = $_SESSION['user']['id'];
  $sql = "SELECT * FROM users WHERE id != '{$user_id}' AND id IS NOT NULL";
  $result = mysqli_query($conn, $sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chats</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/css/chat.css">
    <link rel="stylesheet" type="text/css" href="assets/css/custom.css">
</head>
<body>
 <main>
    <div class="sideNav1"></div>
    <div class="sideNav2">
        <div class="SideNavhead">
           
           <div class="secton-title chat-header">
               <h2>Chats</h2>
               <a href="index.php">
                   Home
               </a>
           </div>

        </div>
        <?php 
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <a href="#" onclick="openChat('<?php echo $_SESSION['user']['id']; ?>', '<?php echo $row['id']; ?>', '<?php echo $row['full_name']; ?>')" style="color: #fff; text-decoration: none;">
            <li class="group">
                <p class="GroupName"><?php echo $row['full_name'] ?></p>
            </li>
        </a>
        <?php } ?>
    </div>
    <section class="Chat">
        <div id="chat-section" style="display: none;">
            <div class="ChatHead">
                <li class="group">
                    <p class="GroupName" id="user-name"></p>

                </li>
            </div>
            <div class="MessageContainer">
                
            </div>
            <form id="MessageForm">
                <input type="text" id="message" name="message">
                <input type="hidden" id="form_sender_id" name="form_sender_id">
                <input type="hidden" id="form_receiver_id" name="form_receiver_id">
                <button class="Send"><i class="fas fa-paper-plane"></i></button>
            </form>
        </div>
    </section>
</main>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<script>

    //here I am calling function to get chat 
    function openChat(sender_id, receiver_id, name) {
        $('#user-name').text(name);
        $('#form_sender_id').val(sender_id);
        $('#form_receiver_id').val(receiver_id);
        $('#chat-section').show();
        $.ajax({
            url: 'submit.php',
            type: 'get',
            data: {
                sender_id: sender_id,
                receiver_id: receiver_id,
                get_chat: "yes"
            },
            success: function(data) {
                displayChatMessages(data, sender_id);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.error('AJAX Error: ', textStatus, errorThrown);
            }
        });
    }

    //this chat is for display message
    function displayChatMessages(messages, sender_id) {
        var container = $('.MessageContainer');

        // Clear existing messages
        container.empty();

        // Iterate through the messages and append them to the container
        messages.forEach(function(message) {
            var messageDiv = $('<div>').addClass('message ' + (message.sender_id == sender_id ? 'me' : 'you'));
            var messageContent = $('<p>').addClass('messageContent').text(message.message);
            var messageDetails = $('<div>').addClass('messageDetails');
            var messageTime = $('<div>').addClass('messageTime').text(formatMessageTime(message.created_at));
            // var messageCheck = $('<i>').addClass('fas fa-check');

            // messageDetails.append(messageTime, messageCheck);
            messageDiv.append(messageContent, messageDetails);
            container.append(messageDiv);
        });
    }

    //this function for time form
    function formatMessageTime(timestamp) {
        if (!timestamp) {
            return '';
        }

        var date = new Date(timestamp);

        if (isNaN(date.getTime())) {
            return '';
        }

        return date.toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    $(document).ready(function() {
        $('#MessageForm').submit(function(e) {
            e.preventDefault();
            var message = $('#message').val();
            var sender_id = $('#form_sender_id').val();
            var receiver_id = $('#form_receiver_id').val();
            var save_chat = "yes";

            if (containsSwearWord(message)) {
                alert("Please don't use swear words.");
                return;
            }

            $.ajax({
                url: 'submit.php',
                type: 'POST',
                data: {
                    sender_id: sender_id,
                    receiver_id: receiver_id,
                    message: message,
                    save_chat: save_chat
                },
                success: function(data) {
                    console.log(data);
                    addMessageToChat(data, sender_id);

                    $('#message').val('');
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('AJAX Error: ', textStatus, errorThrown);
                }
            });
        });
    });

    function containsSwearWord(message) {
        var swearWords = <?php echo json_encode($swearWords); ?>;
        var lowerCaseMessage = message.toLowerCase();
        for (var i = 0; i < swearWords.length; i++) {
            if (lowerCaseMessage.includes(swearWords[i].toLowerCase())) {
                return true;
            }
        }
        return false;
    }

    function addMessageToChat(message, sender_id) {
            var container = $('.MessageContainer');
            var today = new Date().toLocaleDateString();

            var messageDiv = $('<div>').addClass('message ' + (message.sender_id == sender_id ? 'me' : 'you'));
            var messageContent = $('<p>').addClass('messageContent').text(message.message);
            var messageDetails = $('<div>').addClass('messageDetails');

            messageDiv.append(messageContent, messageDetails);
            container.append(messageDiv);
        }
</script>
</body>
</html>